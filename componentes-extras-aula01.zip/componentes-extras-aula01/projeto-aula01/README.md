## Aluraflix

> Lembre-se se rodar "npm install" para rodar o projeto :)